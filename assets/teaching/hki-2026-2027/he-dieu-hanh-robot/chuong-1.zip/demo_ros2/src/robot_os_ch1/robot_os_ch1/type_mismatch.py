"""Deliberately wrong message type. Use only in the isolated turtlesim lesson."""
import rclpy
from rclpy.node import Node
from std_msgs.msg import String


def main(args=None):
    rclpy.init(args=args)
    node = Node('type_mismatch')
    pub = node.create_publisher(String, '/turtle1/cmd_vel', 10)
    timer = node.create_timer(0.1, lambda: pub.publish(String(data='hello')))
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        timer.cancel()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
