from setuptools import setup

setup(
    name='robot_os_ch1', version='1.0.0',
    packages=['robot_os_ch1'],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/robot_os_ch1']),
        ('share/robot_os_ch1', ['package.xml']),
    ],
    install_requires=['setuptools'], zip_safe=True,
    maintainer='Phan Luong Tin', maintainer_email='luongtin@gmail.com',
    description='ROS 2 turtlesim lesson', license='Apache-2.0',
    entry_points={'console_scripts': [
        'circle_driver = robot_os_ch1.circle_driver:main',
        'pose_watcher = robot_os_ch1.pose_watcher:main',
        'type_mismatch = robot_os_ch1.type_mismatch:main',
    ]},
)
