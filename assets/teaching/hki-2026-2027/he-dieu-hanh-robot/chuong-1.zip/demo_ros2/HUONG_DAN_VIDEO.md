# Video dự phòng cho giảng viên

Môi trường đã chạy: Ubuntu 24.04 arm64, ROS 2 Jazzy, turtlesim. Các video ghi lại mô phỏng, không phải robot thật.

- `01_circle.mp4`: driver gửi Twist làm rùa đi theo cung tròn; sau 10 giây driver tiếp tục phát message có vận tốc bằng 0.
- `02_wrong_topic_then_fix.mp4`: tên sai `/turtle1/cmd_vell` không đưa lệnh tới turtlesim; sửa về `/turtle1/cmd_vel` thì rùa chuyển động.
- `03_publisher_stops.mp4`: ngắt riêng driver; turtlesim hết hạn lệnh rồi đứng yên. Pose vẫn tiếp tục được phát.

`pose.csv` chứa thời gian tính từ đầu lần chạy, nhãn giai đoạn, vị trí, góc và vận tốc từ Pose. `verification.json` lưu phép kiểm. Lần chạy này đo được khoảng 0,945 giây từ lúc ngắt publisher đến mẫu Pose đầu tiên có vận tốc bằng 0. Kết quả phụ thuộc lần chạy và không phải cam kết thời gian thực.

Ảnh `rqt_graph_ok.png` là ảnh chụp công cụ; graph trên slide được vẽ lại để nhãn dễ đọc hơn. Node `lesson_probe` và các node CLI trong dữ liệu là công cụ ghi/quan sát của lần kiểm chứng, không phải thành phần bắt buộc trong chương trình sinh viên.
