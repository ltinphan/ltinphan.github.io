import argparse
import json
import uuid
import rclpy
from rclpy.node import Node


def main(args=None):
    argv = rclpy.utilities.remove_ros_args(args=args)
    parser = argparse.ArgumentParser()
    parser.add_argument('--unique', action='store_true')
    options = parser.parse_args(argv[1:])
    name = 'probe_' + uuid.uuid4().hex[:8] if options.unique else 'probe'
    rclpy.init(args=args)
    node = Node(name)
    data = {'node': node.get_fully_qualified_name(), 'namespace': node.get_namespace(),
            'logger': node.get_logger().name,
            'names': {name: node.resolve_topic_name(name) for name in
                      ['turtle1/cmd_vel', '/turtle1/cmd_vel', '~/status']}}
    print(json.dumps(data, ensure_ascii=False), flush=True)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
