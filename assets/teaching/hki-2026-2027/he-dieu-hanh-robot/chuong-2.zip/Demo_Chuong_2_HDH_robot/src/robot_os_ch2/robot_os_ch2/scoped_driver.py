import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from std_msgs.msg import String


class ScopedDriver(Node):
    def __init__(self):
        super().__init__('driver')
        self.pub = self.create_publisher(Twist, 'turtle1/cmd_vel', 10)
        self.status = self.create_publisher(String, '~/status', 10)
        self.sub = self.create_subscription(Pose, 'turtle1/pose', self.on_pose, 10)
        self.ticks = 0
        self.get_logger().info(f'READY cmd={self.pub.topic_name} status={self.status.topic_name}')
        self.timer = self.create_timer(0.1, self.on_timer)

    def on_timer(self):
        msg = Twist()
        if self.ticks < 60:
            msg.linear.x = 1.0
            msg.angular.z = 0.6
        self.pub.publish(msg)
        status = String()
        status.data = 'moving' if self.ticks < 60 else 'zero_command'
        self.status.publish(status)
        if self.ticks == 60:
            self.get_logger().info('STOP_COMMAND: switched to zero Twist')
        self.ticks += 1

    def on_pose(self, msg):
        self.get_logger().debug(f'POSE x={msg.x:.2f} y={msg.y:.2f}', throttle_duration_sec=1.0)


def main(args=None):
    rclpy.init(args=args)
    node = ScopedDriver()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
