import rclpy
from rclpy.node import Node


def main(args=None):
    rclpy.init(args=args)
    node = Node('log_lab')
    logger = node.get_logger()
    logger.debug('DBG: sample=1')
    logger.info('READY: lesson logger active')
    logger.warning('WARN: demonstration only')
    logger.error('ERROR: demonstration only')
    logger.fatal('FATAL: demonstration only; no exit call')
    logger.info('AFTER_FATAL: the program continues')
    for i in range(20):
        logger.info('ONCE: repeated call site', once=True)
        logger.info('THROTTLE: sampled log', throttle_duration_sec=0.5)
        rclpy.spin_once(node, timeout_sec=0.1)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
