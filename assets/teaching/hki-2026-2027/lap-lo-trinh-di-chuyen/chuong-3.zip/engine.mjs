import {MODEL,SCENES,dist,rng,stateFree,edgeFree,pathLength} from './geometry.mjs';
export {MODEL,SCENES,dist,rng,stateFree,edgeFree,pathLength};
export const HAND={nodes:['S','A','B','G'],edges:[['S','A',4],['S','B',1],['B','A',2],['A','G',1],['B','G',7]]};
export function searchGraph({nodes,edges,start,goal,heuristic=()=>0,mode='astar',weight=1,trace=true}){
 const adj=Object.fromEntries(nodes.map(x=>[x,[]]));for(const[u,v,c]of edges){if(c<0)throw Error('Nonnegative costs required');adj[u].push([v,c]);}
 const g=Object.fromEntries(nodes.map(x=>[x,Infinity])),parent={},closed=new Set(),expanded=[],events=[],queue=[];let serial=0,reopens=0,stale=0;g[start]=0;
 const priority=(u)=>mode==='greedy'?heuristic(u):g[u]+(mode==='dijkstra'?0:weight*heuristic(u));
 function push(u){queue.push({u,g:g[u],f:priority(u),h:heuristic(u),serial:serial++});}
 push(start);let success=false;
 while(queue.length){queue.sort((a,b)=>a.f-b.f||a.h-b.h||a.serial-b.serial);const item=queue.shift(),u=item.u;
  if(item.g>g[u]+1e-10||closed.has(u)){stale++;continue;}
  closed.add(u);expanded.push(u);const changes=[];
  if(u===goal){success=true;if(trace)events.push({u,g:{...g},parent:{...parent},changes,open:queue.map(x=>({...x})),closed:[...closed],goal:true});break;}
  for(const[v,c]of adj[u]){const alt=g[u]+c;if(alt+1e-10<g[v]){changes.push({v,old:Number.isFinite(g[v])?g[v]:null,alt,parent:u,c});g[v]=alt;parent[v]=u;if(closed.delete(v))reopens++;push(v);}}
  if(trace)events.push({u,g:{...g},parent:{...parent},changes,open:queue.map(x=>({...x})),closed:[...closed],goal:false});
 }
 const path=[];if(success){for(let u=goal;u!==undefined;u=parent[u]){path.push(u);if(path.length>nodes.length+1)throw Error('Parent cycle');}path.reverse();}
 return{success,cost:success?g[goal]:null,path,expanded,events,g,parent,reopens,stale};
}
export function makeGrid({scene='central',resolution=1,neighbors=8,cutCorners=false,riskWeight=0}={}){
 const nx=Math.round(20/resolution)+1,ny=Math.round(12/resolution)+1,point=(i,j)=>({x:i*resolution,y:j*resolution}),id=(i,j)=>i+','+j;
 const free=(i,j)=>i>=0&&i<nx&&j>=0&&j<ny&&(scene==='risk'?stateFree(point(i,j),'central',.6)&&!(point(i,j).x>=7&&point(i,j).x<=13&&point(i,j).y>=3&&point(i,j).y<=9):stateFree(point(i,j),scene,.6));
 // The risk scene has no solid central obstacle. Its red patch is a synthetic occupancy probability field.
 const isFree=scene==='risk'?(i,j)=>i>=0&&i<nx&&j>=0&&j<ny&&point(i,j).x>.6&&point(i,j).x<19.4&&point(i,j).y>.6&&point(i,j).y<11.4:free;
 const probability=(i,j)=>scene==='risk'&&(point(i,j).x>=7&&point(i,j).x<=13&&point(i,j).y>=4&&point(i,j).y<=8)?.12:.005;
 const dirs=[[1,0],[0,1],[-1,0],[0,-1],...(neighbors===8?[[1,1],[-1,1],[-1,-1],[1,-1]]:[])],nodes=[],edges=[],positions={},probabilities={};
 for(let j=0;j<ny;j++)for(let i=0;i<nx;i++)if(isFree(i,j)){const u=id(i,j);nodes.push(u);positions[u]=point(i,j);probabilities[u]=probability(i,j);}
 for(const u of nodes){const[i,j]=u.split(',').map(Number);for(const[di,dj]of dirs){const a=i+di,b=j+dj;if(!isFree(a,b))continue;
  if(di&&dj&&!cutCorners&&(!isFree(i+di,j)||!isFree(i,j+dj)))continue;
  if(scene!=='risk'&&!edgeFree(point(i,j),point(a,b),scene,.6))continue;
  const length=resolution*Math.hypot(di,dj),risk=-Math.log1p(-probability(a,b));edges.push([u,id(a,b),length+riskWeight*risk]);
 }}
 return{nodes,edges,positions,probabilities,start:id(2/resolution,6/resolution),goal:id(18/resolution,6/resolution),scene,resolution,neighbors,cutCorners,riskWeight,nx,ny};
}
export function solveGrid({heuristic='octile',mode='astar',weight=1,trace=true,...settings}={}){
 const grid=makeGrid(settings),target=grid.positions[grid.goal];
 const h=u=>{if(mode==='dijkstra')return 0;const p=grid.positions[u],dx=Math.abs(p.x-target.x),dy=Math.abs(p.y-target.y);return heuristic==='zero'?0:heuristic==='manhattan'?dx+dy:heuristic==='euclidean'?Math.hypot(dx,dy):Math.max(dx,dy)+(Math.SQRT2-1)*Math.min(dx,dy);};
 const result=searchGraph({...grid,heuristic:h,mode,weight,trace});const points=result.path.map(x=>grid.positions[x]);
 return{...grid,...result,algorithm:mode==='dijkstra'?'Dijkstra':mode==='greedy'?'Greedy':weight===1?'A*':'Weighted A*',heuristic:mode==='dijkstra'?'zero':heuristic,weight,points,length:points.length?pathLength(points):null,risk:result.success?1-Math.exp(result.path.reduce((s,u)=>s+Math.log1p(-grid.probabilities[u]),0)):null};
}
export function samplingTree({star=true,seed=7,budget=1200,scene='central',step=2,gamma=24,bias=.05,trace=false}={}){
 const nodes=[{...MODEL.start,parent:-1,g:0,children:[]}],random=rng(seed),candidates=new Set(),rewires=[],history=[],snapshots=[];let checks=0,first=null,best=null,bestParent=-1;
 const valid=(a,b)=>{checks++;return edgeFree(a,b,scene,.6);};
 function recordBest(it){let value=Infinity,idx=-1;for(const j of candidates){const c=nodes[j].g+dist(nodes[j],MODEL.goal);if(c<value){value=c;idx=j;}}
  if(Number.isFinite(value)){if(first===null)first=it;best=value;bestParent=idx;}history.push({iteration:it,best,checks,nodes:nodes.length,rewires:rewires.length});
 }
 function isAncestor(a,u){while(u>=0){if(u===a)return true;u=nodes[u].parent;}return false;}
 function updateSubtree(root,delta){const todo=[root];while(todo.length){const u=todo.pop();nodes[u].g+=delta;todo.push(...nodes[u].children);}}
 if(trace)snapshots.push({iteration:0,nodes:[{x:MODEL.start.x,y:MODEL.start.y,parent:-1,g:0}],best:null,bestParent:-1});
 for(let it=1;it<=budget;it++){
  const sample=random()<bias?{...MODEL.goal}:{x:20*random(),y:12*random()};let nearest=0,dmin=Infinity;
  for(let j=0;j<nodes.length;j++){const d=dist(nodes[j],sample);if(d<dmin){dmin=d;nearest=j;}}
  if(dmin>1e-10){const a=nodes[nearest],ratio=Math.min(1,step/dmin),q={x:a.x+(sample.x-a.x)*ratio,y:a.y+(sample.y-a.y)*ratio,parent:nearest,g:a.g+Math.min(step,dmin),children:[]};
   if(valid(a,q)){
    const n=nodes.length+1,radius=Math.min(step,gamma*Math.sqrt(Math.log(n)/n)),near=star?nodes.map((p,j)=>({j,d:dist(p,q)})).filter(x=>x.d<=radius+1e-10):[];
    for(const{j,d}of near)if(nodes[j].g+d+1e-10<q.g&&valid(nodes[j],q)){q.parent=j;q.g=nodes[j].g+d;}
    const qi=nodes.length;nodes.push(q);nodes[q.parent].children.push(qi);
    if(star)for(const{j,d}of near){if(j===0||j===q.parent||isAncestor(j,qi))continue;const alt=q.g+d;
     if(alt+1e-10<nodes[j].g&&valid(q,nodes[j])){const oldParent=nodes[j].parent,oldCost=nodes[j].g,delta=alt-oldCost;nodes[oldParent].children=nodes[oldParent].children.filter(x=>x!==j);nodes[j].parent=qi;q.children.push(j);updateSubtree(j,delta);rewires.push({iteration:it,node:j,oldParent,newParent:qi,oldCost,newCost:alt,delta});}
    }
    if(dist(q,MODEL.goal)<=step&&valid(q,MODEL.goal))candidates.add(qi);
   }
  }
  recordBest(it);
  if(trace&&([50,100,200,300,600,1200].includes(it)||it===budget))snapshots.push({iteration:it,nodes:nodes.map(({children,...p})=>({...p})),best,bestParent});
 }
 const path=[];if(bestParent>=0){path.push({...MODEL.goal});for(let j=bestParent;j>=0;j=nodes[j].parent){path.push({x:nodes[j].x,y:nodes[j].y});if(path.length>nodes.length+2)throw Error('Cycle');}path.reverse();if(path.length>1&&dist(path.at(-1),path.at(-2))<1e-9)path.pop();}
 return{algorithm:star?'RRT*':'RRT',seed,budget,scene,step,gamma,bias,nodes:nodes.map(({children,...p})=>p),path,success:best!==null,length:best,first,checks,rewires,history,snapshots};
}
export function validateTree(result){
 for(let i=1;i<result.nodes.length;i++){const n=result.nodes[i],p=result.nodes[n.parent];if(!p||!edgeFree(p,n,result.scene,.6)||Math.abs(n.g-p.g-dist(n,p))>1e-7)return false;let j=i,seen=new Set();while(j>=0){if(seen.has(j))return false;seen.add(j);j=result.nodes[j].parent;}}
 if(result.success&&Math.abs(pathLength(result.path)-result.length)>1e-7)return false;
 return !result.success||result.path.slice(1).every((p,i)=>edgeFree(result.path[i],p,result.scene,.6));
}
