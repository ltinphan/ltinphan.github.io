export const MODEL={width:20,height:12,start:{x:2,y:6},goal:{x:18,y:6},radius:.45,margin:.15};
export const SCENES={central:[{x0:8,x1:12,y0:4,y1:8}],narrow:[{x0:9,x1:11,y0:0,y1:5.1},{x0:9,x1:11,y0:6.9,y1:12}],closed:[{x0:9,x1:11,y0:0,y1:12}]};
export const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
export function rng(seed){let a=seed>>>0;return()=>{a+=0x6D2B79F5;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
const cross=(a,b,c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
function on(p,a,b){return Math.abs(cross(a,b,p))<1e-10&&p.x>=Math.min(a.x,b.x)-1e-10&&p.x<=Math.max(a.x,b.x)+1e-10&&p.y>=Math.min(a.y,b.y)-1e-10&&p.y<=Math.max(a.y,b.y)+1e-10;}
function intersects(a,b,c,d){const v=[cross(a,b,c),cross(a,b,d),cross(c,d,a),cross(c,d,b)];return(v[0]*v[1]<0&&v[2]*v[3]<0)||on(c,a,b)||on(d,a,b)||on(a,c,d)||on(b,c,d);}
function pointSegment(p,a,b){let dx=b.x-a.x,dy=b.y-a.y,l=dx*dx+dy*dy;if(!l)return dist(p,a);let t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/l));return dist(p,{x:a.x+t*dx,y:a.y+t*dy});}
function segmentDistance(a,b,c,d){if(intersects(a,b,c,d))return 0;return Math.min(pointSegment(a,c,d),pointSegment(b,c,d),pointSegment(c,a,b),pointSegment(d,a,b));}
export function pointRect(p,o){return Math.hypot(Math.max(o.x0-p.x,0,p.x-o.x1),Math.max(o.y0-p.y,0,p.y-o.y1));}
export function segmentRect(a,b,o){if(pointRect(a,o)===0||pointRect(b,o)===0)return 0;const v=[{x:o.x0,y:o.y0},{x:o.x1,y:o.y0},{x:o.x1,y:o.y1},{x:o.x0,y:o.y1}];return Math.min(...v.map((p,i)=>segmentDistance(a,b,p,v[(i+1)%4])));}
export function stateFree(p,scene='central',r=.6){return p.x>r&&p.x<20-r&&p.y>r&&p.y<12-r&&SCENES[scene].every(o=>pointRect(p,o)>r+1e-10);}
export function edgeFree(a,b,scene='central',r=.6){return stateFree(a,scene,r)&&stateFree(b,scene,r)&&SCENES[scene].every(o=>segmentRect(a,b,o)>r+1e-10);}
export function pathLength(path){return path.slice(1).reduce((s,p,i)=>s+dist(path[i],p),0);}
export function rrt({seed=7,scene='central',step=.8,budget=800,bias=.08,radius=.45,margin=.15}={}){
 const r=radius+margin,random=rng(seed),nodes=[{...MODEL.start,parent:-1}],trace=[],goal=MODEL.goal;let result=[];
 if(!stateFree(nodes[0],scene,r)||!stateFree(goal,scene,r))return{algorithm:'RRT',seed,scene,nodes,edges:[],path:[],success:false,attempts:0,reason:'invalid_endpoint',trace};
 for(let i=0;i<budget;i++){
  const sample=random()<bias?{...goal}:{x:20*random(),y:12*random()};let nearest=0,dd=Infinity;
  for(let j=0;j<nodes.length;j++){let d=dist(nodes[j],sample);if(d<dd){dd=d;nearest=j;}}
  if(dd<1e-10)continue;const a=nodes[nearest],f=Math.min(1,step/dd),b={x:a.x+f*(sample.x-a.x),y:a.y+f*(sample.y-a.y),parent:nearest};const valid=edgeFree(a,b,scene,r);
  trace.push({i:i+1,sample,nearest,candidate:{x:b.x,y:b.y},valid,before:nodes.length});
  if(!valid)continue;nodes.push(b);
  if(dist(b,goal)<=step&&edgeFree(b,goal,scene,r)){nodes.push({...goal,parent:nodes.length-1});let id=nodes.length-1;while(id>=0){result.push({x:nodes[id].x,y:nodes[id].y});id=nodes[id].parent;}result.reverse();break;}
 }
 const edges=nodes.slice(1).map((p,i)=>[i+1,p.parent]);return{algorithm:'RRT',seed,scene,nodes,edges,path:result,success:result.length>0,attempts:trace.length,length:result.length?pathLength(result):null,trace};
}
function shortest(nodes,edges,start,goal){const adj=nodes.map(()=>[]);for(const[a,b]of edges){const w=dist(nodes[a],nodes[b]);adj[a].push([b,w]);adj[b].push([a,w]);}let ds=nodes.map(()=>Infinity),prev=nodes.map(()=>-1),closed=new Set();ds[start]=0;
 for(let k=0;k<nodes.length;k++){let u=-1;for(let i=0;i<nodes.length;i++)if(!closed.has(i)&&(u===-1||ds[i]<ds[u]))u=i;if(u<0||!Number.isFinite(ds[u]))break;if(u===goal){const path=[];for(let i=goal;i!==-1;i=prev[i])path.push({...nodes[i]});return path.reverse();}closed.add(u);for(const[v,w]of adj[u])if(ds[u]+w<ds[v]){ds[v]=ds[u]+w;prev[v]=u;}}
 return[];
}
export function prm({seed=7,scene='central',samples=200,k=10,connection=3,radius=.45,margin=.15}={}){
 const r=radius+margin,random=rng(seed),nodes=[],edges=[],seen=new Set();let draws=0;
 while(nodes.length<samples&&draws<samples*100){draws++;const p={x:20*random(),y:12*random()};if(stateFree(p,scene,r))nodes.push(p);}
 const roadmapCount=nodes.length;
 function connect(i,eligible){const near=eligible.filter(j=>j!==i).map(j=>({j,d:dist(nodes[i],nodes[j])})).sort((a,b)=>a.d-b.d).filter(x=>x.d<=connection).slice(0,k);for(const{j}of near){const pair=[Math.min(i,j),Math.max(i,j)],key=pair.join(':');if(seen.has(key))continue;seen.add(key);if(edgeFree(nodes[i],nodes[j],scene,r))edges.push(pair);}}
 for(let i=0;i<roadmapCount;i++)connect(i,Array.from({length:roadmapCount},(_,j)=>j));
 const roadmapEdges=edges.length;nodes.push({...MODEL.start},{...MODEL.goal});const start=roadmapCount,goal=start+1;
 if(stateFree(nodes[start],scene,r)&&stateFree(nodes[goal],scene,r)){connect(start,Array.from({length:nodes.length},(_,j)=>j));connect(goal,Array.from({length:nodes.length},(_,j)=>j));}
 const path=shortest(nodes,edges,start,goal);return{algorithm:'PRM',seed,scene,nodes,edges,path,success:path.length>0,length:path.length?pathLength(path):null,roadmapCount,roadmapEdges,draws};
}
export function validateResult(result,{radius=.45,margin=.15}={}){return!result.success||result.path.every(p=>stateFree(p,result.scene,radius+margin))&&result.path.slice(1).every((p,i)=>edgeFree(result.path[i],p,result.scene,radius+margin));}
