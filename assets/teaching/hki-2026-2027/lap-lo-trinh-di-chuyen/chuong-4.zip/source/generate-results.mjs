import fs from 'node:fs';import assert from 'node:assert/strict';
import{stageCost,sqpTrace,simulateMPC,buildQP,solveQP}from './engine.mjs';
const runs=[2,5,10,20].map(N=>simulateMPC({N,preview:true}));
for(const r of runs){assert(r.complete);for(const f of r.frames){assert(f.accepted&&f.primal<1e-5&&f.continuousViolation<1e-5);assert(f.stationarity<1e-7);assert(f.complementarity<1e-4)}}
const limited=simulateMPC({N:5,preview:true,sweeps:1});assert(!limited.complete&&limited.frames.at(-1).k===11);
const disturbed=simulateMPC({N:10,preview:true,disturbance:true});assert(disturbed.complete);
const impossible=simulateMPC({N:10,preview:true,y:3.4,vy:1.3});assert(!impossible.complete&&impossible.states.length===1);
assert(Math.abs(stageCost().u-.5)<1e-12);assert(Math.abs(stageCost({soft:true}).u-20/27)<1e-12);
const sqp=[3,-3,0].map(initial=>sqpTrace({initial}));assert(Math.abs(sqp[0].last.y-1.4)<1e-8);assert(Math.abs(sqp[1].last.y+1.4)<1e-8);assert(sqp[2].last.status==='linearized_subproblem_infeasible');
const data={stage:{hard:stageCost(),soft:stageCost({soft:true})},sqp,runs,limited,disturbed,impossible};
fs.writeFileSync(new URL('../data/browser-rerun.json',import.meta.url),JSON.stringify(data,null,2));
console.log(JSON.stringify({baseline:runs.map(r=>[r.options.N,r.rms,r.finalError]),limitedStop:limited.frames.at(-1).t,feedback:disturbed.rms,checks:'passed'}));
