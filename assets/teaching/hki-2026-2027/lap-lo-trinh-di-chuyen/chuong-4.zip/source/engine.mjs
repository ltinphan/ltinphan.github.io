// Educational numerical models. No ROS or vehicle interface.
export const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
export const dot = (a, b) => a.reduce((s, x, i) => s + x * b[i], 0);
const zeros = n => Array(n).fill(0);

export function stageCost({q = 10, r = 1, limit = 0.5, rho = 10, soft = false} = {}) {
  const raw = 0.5 * q / (0.25 * q + r);
  const u = soft && raw > limit ? (0.5 * q + rho * limit) / (0.25 * q + r + rho) : clamp(raw, -limit, limit);
  const y = 0.5 * u;
  return {q, r, limit, rho, soft, u, y, error: y - 1, tracking: q * (y - 1) ** 2,
    effort: r * u * u, penalty: soft ? rho * Math.max(0, Math.abs(u) - limit) ** 2 : 0,
    violation: Math.max(0, Math.abs(u) - limit)};
}

export const toyJ = y => (y - 0.5) ** 2 + 0.02 * y ** 4;
export function sqpTrace({initial = 3, radius = 1.4, trust = 3, iterations = 12} = {}) {
  let y = initial;
  const rows = [];
  for (let k = 0; k <= iterations; k++) {
    const g = radius ** 2 - y * y, grad = 2 * (y - 0.5) + 0.08 * y ** 3;
    const hess = 2 + 0.24 * y * y, a = -2 * y;
    const row = {k, y, cost: toyJ(y), g, violation: Math.max(0, g), grad, hess};
    rows.push(row);
    if (k === iterations) break;
    let lo = Math.max(-trust, -4 - y), hi = Math.min(trust, 4 - y);
    if (Math.abs(a) < 1e-12) {
      if (g > 1e-10) { row.status = 'linearized_subproblem_infeasible'; break; }
    } else if (a > 0) hi = Math.min(hi, -g / a);
    else lo = Math.max(lo, -g / a);
    if (lo > hi + 1e-12) { row.status = 'linearized_subproblem_infeasible'; break; }
    const step = clamp(-grad / hess, lo, hi);
    row.step = step; row.qpLower = lo; row.qpUpper = hi;
    if (Math.abs(step) < 1e-10 && g < 1e-8) { row.status = 'stationary_local_solution'; break; }
    y += step;
  }
  return {initial, radius, trust, rows, last: rows.at(-1)};
}

export function cholesky(H) {
  const n = H.length, L = Array.from({length: n}, () => zeros(n));
  for (let i = 0; i < n; i++) for (let j = 0; j <= i; j++) {
    let v = H[i][j];
    for (let k = 0; k < j; k++) v -= L[i][k] * L[j][k];
    if (i === j) { if (v <= 0) throw Error('Hessian must be positive definite'); L[i][j] = Math.sqrt(v); }
    else L[i][j] = v / L[j][j];
  }
  return L;
}
export function cholSolve(L, b) {
  const n = L.length, y = zeros(n), x = zeros(n);
  for (let i = 0; i < n; i++) { let v = b[i]; for (let j = 0; j < i; j++) v -= L[i][j] * y[j]; y[i] = v / L[i][i]; }
  for (let i = n - 1; i >= 0; i--) { let v = y[i]; for (let j = i + 1; j < n; j++) v -= L[j][i] * x[j]; x[i] = v / L[i][i]; }
  return x;
}

export function buildQP(options = {}) {
  const o = {N: 10, dt: 0.2, y: 0, vy: 0, lastU: 0, target: 3,
    qy: 2, qv: 1, r: 0.15, rd: 0.8, qf: 8,
    amax: 1.5, vmax: 1.3, rate: 0.8, ymin: -0.5, ymax: 3.5, ...options};
  const {N, dt} = o, H = Array.from({length: N}, () => zeros(N)), f = zeros(N);
  const A = [], b = [], kinds = [], prediction = [];
  function sq(c, bias, weight) {
    for (let i = 0; i < N; i++) { f[i] += 2 * weight * bias * c[i];
      for (let j = 0; j < N; j++) H[i][j] += 2 * weight * c[i] * c[j]; }
  }
  function bound(c, lower, upper, kind) {
    A.push(c.slice(), c.map(x => -x)); b.push(upper, -lower); kinds.push(kind, kind);
  }
  for (let k = 1; k <= N; k++) {
    const cy = zeros(N).map((_, j) => j < k ? dt * dt * (k - j - 0.5) : 0);
    const cv = zeros(N).map((_, j) => j < k ? dt : 0);
    const ybase = o.y + k * dt * o.vy;
    const reference = o.targetSequence?.[k - 1] ?? o.target;
    sq(cy, ybase - reference, o.qy + (k === N ? o.qf : 0)); sq(cv, o.vy, o.qv);
    const cu = zeros(N); cu[k - 1] = 1; sq(cu, 0, o.r);
    const cd = cu.slice(); if (k > 1) cd[k - 2] = -1;
    sq(cd, k === 1 ? -o.lastU : 0, o.rd);
    bound(cy, o.ymin - ybase, o.ymax - ybase, 'y_m');
    bound(cv, -o.vmax - o.vy, o.vmax - o.vy, 'vy_mps');
    bound(cu, -o.amax, o.amax, 'a_mps2');
    const shift = k === 1 ? o.lastU : 0;
    bound(cd, shift - o.rate, shift + o.rate, 'delta_a_mps2');
    prediction.push({cy, cv, ybase});
  }
  return {H, f, A, b, kinds, prediction, options: o};
}

export function solveQP(qp, {sweeps = 1200, warmLambda = null, tolerance = 1e-7} = {}) {
  const {H, f, A, b} = qp, L = cholesky(H), n = H.length;
  const directions = A.map(a => cholSolve(L, a)), diagonal = A.map((a, i) => dot(a, directions[i]));
  const u = cholSolve(L, f.map(x => -x));
  const lambda = A.map((_, i) => Math.max(0, warmLambda?.[i] || 0));
  for (let i = 0; i < A.length; i++) for (let j = 0; j < n; j++) u[j] -= lambda[i] * directions[i][j];
  let change = Infinity, count = 0, converged = false;
  for (; count < sweeps; count++) {
    change = 0;
    for (let i = 0; i < A.length; i++) {
      const next = Math.max(0, lambda[i] + (dot(A[i], u) - b[i]) / diagonal[i]);
      const d = next - lambda[i]; lambda[i] = next;
      change = Math.max(change, Math.abs(d) * Math.sqrt(diagonal[i]));
      for (let j = 0; j < n; j++) u[j] -= d * directions[i][j];
    }
    const primal = Math.max(0, ...A.map((a, i) => dot(a, u) - b[i]));
    if (change < tolerance && primal < tolerance) { converged = true; count++; break; }
  }
  const stationarity = H.map((row, j) => dot(row, u) + f[j] + A.reduce((s, a, i) => s + a[j] * lambda[i], 0));
  const slacks = A.map((a, i) => b[i] - dot(a, u));
  const violations = {};
  qp.kinds.forEach((kind, i) => violations[kind] = Math.max(violations[kind] || 0, -slacks[i]));
  const predicted = qp.prediction.map(p => ({y: p.ybase + dot(p.cy, u), vy: qp.options.vy + dot(p.cv, u)}));
  let continuousViolation = 0, state = {y: qp.options.y, vy: qp.options.vy};
  for (const a of u) {
    const times = [0, qp.options.dt];
    if (Math.abs(a) > 1e-12) { const t = -state.vy / a; if (t > 0 && t < qp.options.dt) times.push(t); }
    for (const t of times) {
      const y = state.y + t * state.vy + 0.5 * t * t * a;
      continuousViolation = Math.max(continuousViolation, qp.options.ymin - y, y - qp.options.ymax);
    }
    state = {y: state.y + qp.options.dt * state.vy + 0.5 * qp.options.dt ** 2 * a, vy: state.vy + qp.options.dt * a};
  }
  return {u, lambda, predicted, converged, sweeps: count, change,
    cost: 0.5 * dot(u, H.map(row => dot(row, u))) + dot(f, u),
    primal: Math.max(0, ...slacks.map(x => -x)), violations,
    stationarity: Math.max(...stationarity.map(Math.abs)),
    complementarity: Math.max(...slacks.map((s, i) => Math.abs(s * lambda[i]))), continuousViolation};
}

export function referenceAt(t, target = 3, preview = false) {
  if (!preview) return target;
  if (t <= 2) return 0;
  if (t >= 4) return target;
  return target * 0.5 * (1 - Math.cos(Math.PI * (t - 2) / 2));
}

export function simulateMPC(options = {}) {
  const o = {steps: 40, sweeps: 1200, deadlineMs: Infinity, warm: true, disturbance: false, ...options};
  let y = o.y || 0, vy = o.vy || 0, lastU = 0, warmLambda = null;
  const frames = [], states = [{t: 0, y, vy}];
  for (let k = 0; k < o.steps; k++) {
    if (o.disturbance && k === 12) vy += 0.15;
    const dt = o.dt ?? 0.2, N = o.N ?? 10;
    const targetSequence = Array.from({length:N}, (_, j) => referenceAt((k+j+1)*dt,o.target ?? 3,o.preview));
    const qp = buildQP({...o, y, vy, lastU,targetSequence});
    const begin = performance.now();
    const result = solveQP(qp, {sweeps: o.sweeps, warmLambda: o.warm ? warmLambda : null});
    const elapsedMs = performance.now() - begin;
    const accepted = result.converged && result.primal < 1e-5 && result.continuousViolation < 1e-5 && elapsedMs <= o.deadlineMs;
    const frame = {k, t: k * qp.options.dt, y, vy, elapsedMs, accepted, ...result};
    frames.push(frame);
    if (!accepted) break; // Pause this educational simulation; this is not a vehicle stop controller.
    const u = result.u[0];
    y += dt * vy + 0.5 * dt * dt * u; vy += dt * u; lastU = u;
    states.push({t: (k + 1) * dt, y, vy, appliedU: u});
    warmLambda = result.lambda.map((_, i, a) => a[i + 8] || 0);
  }
  const target = o.target ?? 3;
  return {options: o, frames, states, complete: states.length === o.steps + 1,
    rms: Math.sqrt(states.reduce((s, a) => s + (a.y - referenceAt(a.t,target,o.preview)) ** 2, 0) / states.length),
    finalError: states.at(-1).y - target,
    maxInput: Math.max(0, ...states.map(s => Math.abs(s.appliedU || 0))),
    maxPrimal: Math.max(0, ...frames.map(f => f.primal))};
}
