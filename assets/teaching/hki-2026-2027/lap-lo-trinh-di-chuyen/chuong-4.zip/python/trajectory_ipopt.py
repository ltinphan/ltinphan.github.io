"""Reproducible teaching examples: CasADi/IPOPT.

All trajectories are simulations. No vehicle or ROS interface is provided.
"""
import json, math, time, sys
from pathlib import Path
import numpy as np
import casadi as ca

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'data'
OUT.mkdir(exist_ok=True)

def toy(initial):
    y = ca.MX.sym('y')
    cost = (y - 0.5)**2 + 0.02*y**4
    solver = ca.nlpsol('toy', 'ipopt', {'x': y, 'f': cost, 'g': 1.4**2-y*y},
        {'ipopt.print_level': 0, 'print_time': False, 'ipopt.sb': 'yes',
         'ipopt.tol': 1e-10, 'ipopt.max_iter': 100})
    start = time.perf_counter()
    sol = solver(x0=initial, lbx=-4, ubx=4, lbg=-ca.inf, ubg=0)
    yopt = float(sol['x'])
    return {'initial': initial, 'y': yopt, 'cost': float(sol['f']),
        'violation': max(0, 1.4**2-yopt*yopt),
        'status': solver.stats()['return_status'], 'iterations': solver.stats()['iter_count'],
        'elapsed_ms': (time.perf_counter()-start)*1000}

def bicycle(branch=1, margin=0):
    # Rear-axle kinematic bicycle. RK4 with piecewise-constant controls.
    N, dt, L = 30, 0.2, 2.8
    x = ca.MX.sym('s', 4); u = ca.MX.sym('u', 2)
    rhs = ca.Function('rhs', [x,u], [ca.vertcat(x[3]*ca.cos(x[2]), x[3]*ca.sin(x[2]),
        x[3]*ca.tan(u[1])/L, u[0])])
    def step(x,u,h):
        k1=rhs(x,u); k2=rhs(x+h*k1/2,u); k3=rhs(x+h*k2/2,u); k4=rhs(x+h*k3,u)
        return x+h*(k1+2*k2+2*k3+k4)/6
    opt=ca.Opti(); X=opt.variable(4,N+1); U=opt.variable(2,N)
    opt.subject_to(X[:,0]==[0,0,0,3])
    opt.subject_to(opt.bounded(-2,U[0,:],2)); opt.subject_to(opt.bounded(-0.45,U[1,:],0.45))
    opt.subject_to(opt.bounded(0.5,X[3,:],5)); opt.subject_to(opt.bounded(-4,X[1,:],4))
    objective=0
    for k in range(N):
        opt.subject_to(X[:,k+1]==step(X[:,k],U[:,k],dt))
        delta_prev=U[1,k-1] if k else 0
        opt.subject_to(opt.bounded(-0.1,U[1,k]-delta_prev,0.1))
        # A disc collision model, not a rectangular vehicle footprint.
        opt.subject_to((X[0,k+1]-9)**2+X[1,k+1]**2 >= (1.6+margin)**2)
        objective += dt*(0.3*(X[0,k+1]-3*dt*(k+1))**2+X[1,k+1]**2
            +2*X[2,k+1]**2+0.5*(X[3,k+1]-3)**2+0.1*U[0,k]**2
            +0.5*U[1,k]**2+5*(U[1,k]-delta_prev)**2)
    objective += 100*ca.sumsqr(X[:,N]-ca.DM([18,0,0,3]))
    opt.minimize(objective)
    xx=np.linspace(0,18,N+1); yy=branch*2.8*np.sin(np.pi*xx/18)**2
    psi=np.arctan(np.gradient(yy,xx))
    opt.set_initial(X,np.vstack([xx,yy,psi,np.full(N+1,3)])); opt.set_initial(U,0)
    opt.solver('ipopt', {'expand': True, 'print_time': False},
        {'print_level':0,'sb':'yes','tol':1e-8,'max_iter':1000})
    start=time.perf_counter(); sol=opt.solve(); elapsed=(time.perf_counter()-start)*1000
    states=np.asarray(sol.value(X)).T; controls=np.asarray(sol.value(U)).T
    g=np.asarray(sol.value(opt.g)).reshape(-1); lo=np.asarray(sol.value(opt.lbg)).reshape(-1); hi=np.asarray(sol.value(opt.ubg)).reshape(-1)
    residual=float(max(0,np.max(lo-g),np.max(g-hi)))
    defects=[]; dense=[]; current=states[0].copy()
    for k in range(N):
        predicted=np.asarray(step(states[k],controls[k],dt)).reshape(-1)
        defects.append(float(np.max(np.abs(predicted-states[k+1]))))
        # Sample a separately integrated rollout at 20 substeps/hold.
        current=states[k].copy()
        for j in range(20):
            current=np.asarray(step(current,controls[k],dt/20)).reshape(-1)
            dense.append(current.tolist())
    dense=np.asarray(dense)
    node_clearance=np.sqrt((states[:,0]-9)**2+states[:,1]**2)-1.6
    dense_clearance=np.sqrt((dense[:,0]-9)**2+dense[:,1]**2)-1.6
    return {'branch':branch,'margin':margin,'N':N,'dt':dt,'L':L,'initial':[0,0,0,3],
        'obstacle':{'x':9,'y':0,'effective_radius':1.6},'states':states.tolist(),
        'controls':controls.tolist(),'dense_rollout':dense.tolist(),'cost':float(sol.value(objective)),
        'status':sol.stats()['return_status'],'iterations':sol.stats()['iter_count'],
        'elapsed_ms':elapsed,'constraint_residual':residual,'dynamics_residual':max(defects),
        'node_clearance_m':float(node_clearance.min()),'sampled_clearance_m':float(dense_clearance.min()),
        'dense_sampling_per_interval':20,'dense_check_is_continuous_certificate':False}

if __name__=='__main__':
    data={'versions':{'python':sys.version.split()[0],'casadi':ca.__version__,'numpy':np.__version__},
        'toy_ipopt':[toy(3),toy(-3),toy(0)],
        'bicycle':[bicycle(1,0),bicycle(-1,0),bicycle(1,0.05),bicycle(-1,0.05)]}
    (OUT/'ipopt-rerun.json').write_text(json.dumps(data,indent=2))
    for d in data['bicycle']:
        print('branch',d['branch'],'margin',d['margin'],'status',d['status'],
              'node',d['node_clearance_m'],'dense',d['sampled_clearance_m'])
