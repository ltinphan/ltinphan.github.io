# Thực hành Chương 4 — Lập lộ trình di chuyển

Đại học Nguyễn Tất Thành · HKI 2026–2027.

## Mở thí nghiệm

Giải nén toàn bộ gói rồi mở `demo.html` bằng Chrome, Edge, Firefox hoặc Safari. Bốn thí nghiệm chạy ngoại tuyến; liên kết Teaching và tài liệu cần Internet. Không cần cài ROS 2 để dùng phần trình duyệt.

1. **Chi phí và giới hạn:** giữ q=10, r=1, giới hạn 0,5 m/s². Giới hạn cứng cho a=0,5; phạt mềm rho=10 cho a=20/27≈0,74074 m/s², vượt 0,24074 m/s². So riêng từng thành phần chi phí và mức vi phạm.
2. **SQP giản lược:** khởi tạo 3 và −3, r=1,4. Hai nhánh dừng gần ±1,4, chi phí tương ứng 0,886832 và 3,686832. Khởi tạo 0 làm bài toán con tuyến tính hóa vô nghiệm; NLP gốc vẫn có nghiệm. Biến y đã chuẩn hóa, không phải toàn bộ quỹ đạo xe.
3. **IPOPT:** trang phát lại bốn kết quả mẫu. Không thêm biên, kiểm nút gần 0 nhưng kiểm dày có khoảng hở −0,026864 m. Thêm 0,05 m tại nút, kiểm dày còn +0,023919 m. Kiểm 20 mẫu/giữ điều khiển chưa là chứng chỉ tránh va chạm liên tục.
4. **MPC:** N=10, ngân sách 1200, hạn riêng QP 200 ms, mô phỏng đủ 40 chu kỳ/8 s cho RMSE khoảng 0,2444 m. N=5/10/20 cho RMSE 0,3475/0,2444/0,2653 m. Với N=5 và chỉ 1 lượt quét, chu kỳ 11 ở 2,2 s chưa đạt điều kiện nhận. Tăng lại 1200 để đối chiếu. Tùy chọn tác động cộng 0,15 m/s vào vận tốc ngang tại 2,4 s; giữ các tham số gốc khác để quan sát phản hồi.

## Chạy IPOPT thật bằng Python

Đã kiểm tra với Python 3.12; dùng môi trường ảo mới. Từ thư mục giải nén:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r python/requirements.txt
python python/trajectory_ipopt.py
```

Windows: kích hoạt bằng `.venv\Scripts\activate` thay cho lệnh `source`. Kết quả mới ghi vào `data/ipopt-rerun.json`, không ghi đè dữ liệu mẫu. Thời gian thực thi phụ thuộc máy. Tải gói Python yêu cầu Internet; sau khi cài, bộ giải chạy trên máy.

Mô hình xe đạp tâm trục sau dùng RK4, L=2,8 m, N=30, dt=0,2 s; trạng thái (x,y,psi,v), điều khiển (a,delta). Vùng cấm cho điểm theo dõi: tâm (9,0), bán kính hiệu dụng 1,6 m. Đây không phải footprint hình chữ nhật. Các hàm lượng giác dùng radian. Ràng buộc nút được kiểm lại bằng rollout 20 mẫu/khoảng. Chi phí cộng cả bám mốc tiến, vị trí ngang, hướng, tốc độ, điều khiển, đổi góc lái và chi phí cuối; các hệ số được ghi rõ trong mã.

## Mô hình MPC và nguồn chạy lại

`source/engine.mjs` chứa toàn bộ tính toán của demo; Node.js 22 đã được kiểm tra. Chạy `node source/generate-results.mjs` để tạo `data/browser-rerun.json` và kiểm các điều kiện nhận nghiệm. Hildreth trên đối ngẫu, giải Cholesky; nghiệm QP đã được đối chiếu độc lập bằng SciPy SLSQP trên 6 bài toán cùng ma trận.

Mô hình ngang: y_next=y+dt*vy+0,5*dt²*ay; vy_next=vy+dt*ay, dt=0,2 s. Các thang chuẩn hóa bằng 1 đơn vị SI tương ứng. Giới hạn y∈[−0,5;3,5] m, |vy|≤1,3 m/s, |ay|≤1,5 m/s², |Δay|≤0,8 m/s² mỗi chu kỳ. Trọng số gốc qy=2, qv=1, r=0,15, rd=0,8, qf=8. Tham chiếu 0 trước 2 s; 1,5(1−cos(pi(t−2)/2)) trong 2–4 s; 3 m sau đó. Ma trận QP được xây dựng từ chính công thức này.

Mỗi chu kỳ phải hội tụ, qua kiểm ràng buộc và cực trị parabol, đồng thời không trễ hạn đo riêng bộ QP. Khi chưa đạt, demo dừng mô phỏng và không áp lệnh mới. Đây không phải chính sách dừng xe an toàn. Thời gian chưa gồm I/O hoặc ROS 2. Warm start dùng bộ nhân đối ngẫu dịch theo 8 ràng buộc trên mỗi bước, không áp trực tiếp chuỗi lệnh cũ.

## Báo cáo

Lưu JSON/CSV bằng nút trong demo. Mỗi phép thử ghi cấu hình, giả định, kết quả trước/sau khi đổi một yếu tố, cả lần bị loại và giải thích. RMSE phải kèm số mốc và thời lượng; không so RMSE của lần dừng sớm như thể đã chạy đủ 8 s. Bài toán không đủ khoảng dừng ngang: y=3,4 m, vy=1,3 m/s, biên 3,5 m; tối thiểu cần 1,3²/(2×1,5)≈0,5633 m, lớn hơn khoảng còn 0,1 m.

## Tài liệu

- https://underactuated.mit.edu/trajopt.html
- https://web.casadi.org/docs/
- https://coin-or.github.io/Ipopt/
- https://sites.engineering.ucsb.edu/~jbraw/mpc/MPC-book-2nd-edition-5th-printing.pdf

Các hình và kết quả là mô hình giảng dạy, chưa kiểm chứng xe/cảm biến thực. Gói không có giao diện gửi lệnh tới robot.

## Video và ảnh chụp

Thư mục `videos/` có hai video ghi từ demo IPOPT/MPC và một video mô phỏng ETH MPCC. Mở MP4 bằng trình phát video; xem nguồn và giấy phép ở `MEDIA-SOURCES.md`. Video xe, robot thật được nhúng từ kênh Stanford và Biomimetics MIT trên Teaching, không sao chép vào gói.

Trong demo, chọn cấu hình rồi bấm **Ghi video mô phỏng IPOPT/MPC** để lưu WebM từ đồ thị đang chạy. Chức năng ghi canvas không dùng camera hoặc microphone. Giữ tab hoạt động trong lúc ghi.
