import math,json,sys
from pathlib import Path
import numpy as np
from PIL import Image
import manimgx as m
R=Path(__file__).resolve().parents[1];O=R/'figures/generated';O.mkdir(parents=True,exist_ok=True)
PLAN=json.loads((R/'data/figure-plan.json').read_text());DATA=json.loads((R/'data/reference-results.json').read_text())
BLUE='#045EA7';GOLD='#A17C00';RED='#95001A';GRAY='#6B7E8F';LIGHT='#E8F0F5';DARK='#222222';GREEN='#23785A'
m.config.background_color='#FFFFFF';m.config.background_opacity=0;m.config.pixel_width=3200;m.config.pixel_height=1800;m.config.frame_rate=30
p=lambda a:[float(a[0]),float(a[1]),0]
def txt(s,a=(0,0),size=48,color=DARK,width=13):
 o=m.Text(s,font='Times New Roman',font_size=size,color=color)
 if o.width>width:o.scale_to_fit_width(width)
 return o.move_to(p(a))
def eq(s,a=(0,0),size=62,color=BLUE,width=13):
 o=m.MathTex(s,font_size=size,color=color)
 if o.width>width:o.scale_to_fit_width(width)
 return o.move_to(p(a))
def ln(a,b,col=GRAY,w=4):return m.Line(p(a),p(b),color=col,stroke_width=w)
def arr(a,b,col=BLUE,w=5):return m.Arrow(p(a),p(b),color=col,stroke_width=w,buff=.1)
def rect(a,w,h,col=BLUE,fill=.08):return m.Rectangle(width=w,height=h,stroke_color=col,stroke_width=4,fill_color=col,fill_opacity=fill).move_to(p(a))
def dot(a,col=BLUE,r=.1):return m.Dot(p(a),radius=r,color=col)
def circ(a,r,col=BLUE,fill=.08):return m.Circle(radius=r,stroke_color=col,stroke_width=4,fill_color=col,fill_opacity=fill).move_to(p(a))
def path(pts,col=BLUE,w=6):return m.VMobject(color=col,stroke_width=w).set_points_as_corners([p(x)for x in pts])
def car(a=(0,0),angle=0,col=BLUE,scale=1):
 g=m.VGroup(rect((0,0),2.2,.9,col,.16),rect((.2,0),.9,.7,col,.06),ln((-.75,-.43),(-.4,-.43),DARK,9),ln((-.75,.43),(-.4,.43),DARK,9),ln((.6,-.43),(.95,-.43),DARK,9),ln((.6,.43),(.95,.43),DARK,9),arr((.4,0),(1.45,0),col,4));return g.rotate(angle).scale(scale).move_to(p(a))
def person(a=(0,0),col=GOLD,scale=1):
 g=m.VGroup(circ((0,.35),.16,col,0),ln((0,.18),(0,-.25),col,5),ln((-.25,0),(.25,0),col,5),ln((0,-.25),(-.22,-.6),col,5),ln((0,-.25),(.22,-.6),col,5));return g.scale(scale).move_to(p(a))
def flow(labels,cycle=False):
 xs=np.linspace(-5,5,len(labels));g=m.VGroup()
 for j,(x,s)in enumerate(zip(xs,labels)):
  col=BLUE if j%2==0 else GOLD
  words=s.split();cut=max(1,len(words)//2);label=(' '.join(words[:cut])+'\n'+' '.join(words[cut:]))if len(words)>=3 else s
  g.add(rect((x,.05),2.7,3.3,col,.035),txt(label,(x,.92),36 if '\n'in label else 42,col,width=2.45))
  if any(w in s for w in ['Quan sát','Theo dõi','Đo','Quan sát mới']):
   g.add(car((x,-.55),col=col,scale=.57))
   for ang in [-.7,0,.7]:g.add(ln((x-.9,-.55),(x-.9+1.9*math.cos(ang),-.55+1.9*math.sin(ang)),col,2))
  elif any(w in s for w in ['Dự','Lịch','Thời gian','Cấu hình','Sai khác','Trễ']):
   for z in range(3):g.add(circ((x-.65+z*.65,-.5+.18*z),.13,col,.1))
   g.add(path([(x-.65,-.5),(x,-.32),(x+.65,-.14)],col,3),eq(r't_0\to t_1',(x,-1.2),36,col,width=2.3))
  elif any(w in s for w in ['Phối hợp','Giao lộ','Người','Vùng khuất','Quyết định']):
   g.add(car((x-.45,-.5),col=col,scale=.5),person((x+.65,-.4),RED,.67),arr((x-.8,-1.25),(x+.7,-1.25),col,3))
  elif any(w in s for w in ['Kiểm','Giới hạn','Kết luận','Bằng chứng','Phản ví dụ','Giả định','Mô hình']):
   g.add(rect((x-.43,-.55),.85,.65,col,.08),rect((x+.52,-.55),.55,.65,GRAY,.08),eq(r'\cap=\varnothing',(x,-1.25),36,col,width=2.3))
  else:
   g.add(ln((x-.9,-1.15),(x+.9,-1.15),GRAY,2),ln((x-.9,-1.15),(x-.9,-.05),GRAY,2),path([(x-.8,-1),(x-.25,-.4),(x+.25,-.55),(x+.8,-.1)],col,4))
  if j:g.add(arr((xs[j-1]+1.4,.25),(x-1.4,.25),GRAY,4))
 if cycle:g.add(ln((5,-1.7),(5,-2.3),GOLD),ln((5,-2.3),(-5,-2.3),GOLD),arr((-5,-2.3),(-5,-1.7),GOLD))
 return g

def road(inter=False):
 g=m.VGroup(rect((0,0),12,2.8,GRAY,.04),ln((-6,0),(6,0),GRAY,2))
 if inter:g.add(rect((0,0),2.8,7,GRAY,.04),rect((0,0),2.2,2.2,RED,.07))
 return g

def axes(curves,xlim,ylim,labels=(r't\ (\mathrm s)',r's\ (\mathrm m)'),size=(10,4.1),origin=(-5,-2)):
 x0,y0=origin;w,h=size;xn,xx=xlim;yn,yx=ylim
 xy=lambda x,y:(x0+(x-xn)/(xx-xn)*w,y0+(y-yn)/(yx-yn)*h)
 g=m.VGroup(ln((x0,y0),(x0+w,y0),GRAY,3),ln((x0,y0),(x0,y0+h),GRAY,3))
 for z in np.linspace(xn,xx,5):
  a=xy(z,yn);g.add(ln((a[0],a[1]-.07),(a[0],a[1]+.07),GRAY,2),eq(f'{z:.3g}',(a[0],a[1]-.4),34,GRAY,width=2))
 for z in np.linspace(yn,yx,3):a=xy(xn,z);g.add(eq(f'{z:.3g}',(a[0]-.45,a[1]),34,GRAY,width=2))
 g.add(eq(labels[0],(x0+w-.3,y0-.95),42,BLUE,width=3),eq(labels[1],(x0-.2,y0+h+.5),42,BLUE,width=4))
 for pts,col in curves:
  pts=[xy(x,y)for x,y in pts if xn<=x<=xx and yn<=y<=yx]
  if len(pts)>1:g.add(path(pts,col))
 return g,xy

def timeline_scene(n):
 g=m.VGroup()
 if n==5:
  labels=['Mô hình thời gian','Phối hợp','Vật cản động','Tương tác'];mins=[43,40,51,76]
  for j,x in enumerate(np.linspace(-4.7,4.7,4)):g.add(rect((x,.3),2.7,1.8,BLUE if j%2==0 else GOLD),txt(labels[j],(x,.6),40,width=2.5),eq(str(mins[j])+r'\ \mathrm{phút}',(x,-.15),40,GOLD,width=2.4))
  g.add(txt('210 phút học + 2 lần nghỉ × 15 phút',(0,-2),45,BLUE))
 else:
  for j in range(12):a=j*math.pi/6;g.add(ln((1.75*math.sin(a),1.75*math.cos(a)),(1.95*math.sin(a),1.95*math.cos(a)),GRAY,4))
  g.add(circ((0,0),2.15,BLUE,0),ln((0,0),(0,1.5),BLUE,9),ln((0,0),(1.3,0),GOLD,9),dot((0,0),RED,.15),txt('15 phút',(0,-3),55,BLUE))
 return g

def slots(n):
 d=DATA['intersection'][1];g=m.VGroup();xmin,xmax=3.5,9;xy=lambda t:-5+(t-xmin)/(xmax-xmin)*10
 for j,(label,interval,col)in enumerate([('A',[4.65,6.35],BLUE),('B gốc',[4.65,6.35],RED),('B dời',[6.85,8.55],GOLD)]):
  y=1.5-j*1.5;g.add(txt(label,(-5.9,y),42,col,width=1.6),ln((-4.8,y),(5.7,y),GRAY,2),rect(((xy(interval[0])+xy(interval[1]))/2,y),xy(interval[1])-xy(interval[0]),.6,col,.17),eq(f'{interval[0]:.2f}',(xy(interval[0]),y-.55),35,col,width=1.4),eq(f'{interval[1]:.2f}',(xy(interval[1]),y-.55),35,col,width=1.4))
 g.add(arr((xy(6.35),2.25),(xy(6.85),2.25),GOLD,4),eq(r'0{,}5\ \mathrm s',(xy(6.6),2.8),40,GOLD,width=3));return g

def intersection_scene(kind,n):
 g=road(True)
 if kind in ['reservation','footprint']:
  g.add(rect((0,0),3.4,3.4,RED,.05),eq(r'K=3{,}4\ \mathrm m',(3.8,2.4),48,RED,width=5))
 x,y=(-3.9,-3.9)if n not in [12,29]else(-.8,-.4)
 g.add(car((x,0),col=BLUE),car((0,y),math.pi/2,GOLD),arr((-5.7,-1.9),(3.8,-1.9),BLUE),arr((1.9,-3.2),(1.9,2.8),GOLD))
 if kind=='priority':g.add(txt('A trước',(-3.8,2.4),49,BLUE,width=4),txt('B chờ',(3.5,-2.8),49,GOLD,width=4))
 elif kind=='go_wait':g.add(txt('Đủ thời gian đi trước?',(-3.6,2.4),43,BLUE,width=5),txt('Đủ khoảng dừng?',(3.7,-2.9),43,GOLD,width=5))
 elif kind=='deadlock':g.add(txt('Cùng chờ',(-3.7,2.4),49,RED,width=5),txt('Chưa hoàn thành',(3.7,-2.9),44,RED,width=5))
 else:g.add(txt('Kiểm cùng\nthời điểm',(-3.9,2.5),43,BLUE,width=4))
 return g

def pedestrian_scene(kind,n):
 g=road();g.add(car((-3.7,0),col=BLUE),person((1.3,-2.4),GOLD,1.1),arr((1.3,-1.7),(1.3,2.1),GOLD),ln((1.3,-1.4),(1.3,1.4),RED,3))
 for x in np.linspace(.4,2.2,7):g.add(rect((x,0),.12,2.55,GRAY,.1))
 if kind in ['yield','hri','intent']:g.add(txt('Giảm tốc sớm',(-3.7,2.4),48,BLUE,width=5),txt('Khoảng trống dễ đọc',(3.1,3.1),44,GOLD,width=6))
 elif kind=='noncooperative':g.add(person((1.3,1.8),GRAY,.7),txt('Không tự chọn hành động của người',(0,3.1),44,RED,width=12))
 else:g.add(eq(r'v_0=8\ \mathrm{m/s}',(-3.8,2.6),48,BLUE,width=5),eq(r'v_p=1{,}5\ \mathrm{m/s}',(3.5,-2.8),47,GOLD,width=5))
 return g

def relative_scene(kind,n):
 if kind=='distance_ttc':
  g=m.VGroup(car((-4,1.2),col=BLUE),car((-1,1.2),col=GOLD),arr((-1,2.3),(2,2.3),GOLD),txt('Gần nhưng tách xa',(1.2,3.0),43,GOLD,width=5),car((-5,-1.5),col=BLUE),car((4,-1.5),math.pi,GOLD),arr((2.3,-2.4),(-.3,-2.4),RED),txt('Xa nhưng đang gần lại',(0,-3.2),45,RED,width=9));return g
 if kind in ['cpa','horizon']:
  H=2 if kind=='horizon'else 6;ts=np.linspace(0,6,150);g,xy=axes([([(t,abs(10-2.5*t))for t in ts],BLUE)],(0,6),(0,11),(r'\tau\ (\mathrm s)',r'd(\tau)\ (\mathrm m)'))
  at=2 if kind=='horizon'else 4;g.add(ln(xy(at,0),xy(at,11),GOLD,4),dot(xy(at,abs(10-2.5*at)),GOLD,.14),eq(r'H=2\ \mathrm s'if kind=='horizon'else r'\tau_{\rm CPA}=4\ \mathrm s',(1.8,2.2),45,GOLD,width=6),txt('Cực tiểu trong cửa sổ'if kind=='horizon'else'Khoảng cách hai tâm',(0,-3.3),44,GRAY,width=11));return g
 g=m.VGroup(ln((-5,-2.1),(5,-2.1),GRAY,3),ln((-5,-2.1),(-5,2.3),GRAY,3));a=(-3.6,-1.2);b=(3.2,1.6);g.add(circ(a,.45,BLUE),circ(b,.45,GOLD),arr(a,b,BLUE),arr(b,(-2.5,-1),GOLD),eq(r'\mathbf r',(0,1.3),60,BLUE,width=2),eq(r'\mathbf w',(2.1,-1),60,GOLD,width=2),txt('Mô hình hai đĩa, vận tốc giữ nguyên',(0,-3),44,GRAY,width=12))
 if kind in ['cpa','ttc','horizon']:g.add(circ(a,1.2,RED,0),dot((-1.9,-.45),RED,.15),eq(r'\tau_{\rm TTC}=3{,}2\ \mathrm s',(1.5,2.8),46,RED,width=7))
 return g

def stopping_scene(kind,n):
 if kind in ['quiz_stop','answer_stop']:
  vv=np.linspace(0,8.5,150);g,xy=axes([([(v,.6*v+v*v/6)for v in vv],BLUE)],(0,8.5),(0,18),(r'v_0\ (\mathrm{m/s})',r'd_{\rm stop}\ (\mathrm m)'))
  vmax=-1.8+math.sqrt(39.24);g.add(ln(xy(0,6),xy(8.5,6),RED,4),dot(xy(vmax,6),GOLD,.15),ln(xy(vmax,0),xy(vmax,6),GOLD,3),eq(r'\tau_d=0{,}6\ \mathrm s',(1.8,2),43,BLUE,width=5),eq(r'v_{\max}\approx4{,}464',(-.5,-3.2),46,GOLD,width=8));return g
 if kind in ['stop_distance','delay_compare','quiz_stop','answer_stop']:
  curves=[]
  for tau,col in [(.2,BLUE),(.8,GOLD)]:curves.append(([(v,v*tau+v*v/6)for v in np.linspace(0,10,150)],col))
  g,xy=axes(curves,(0,10),(0,26),(r'v_0\ (\mathrm{m/s})',r'd_{\rm stop}\ (\mathrm m)'))
  for tau,col in [(.2,BLUE),(.8,GOLD)]:g.add(dot(xy(8,8*tau+64/6),col,.13))
  g.add(eq(r'\tau_d=0{,}2',(-1.7,1.6),40,BLUE,width=4),eq(r'\tau_d=0{,}8',(2.4,1.6),40,GOLD,width=4));return g
 g=m.VGroup(ln((-5,-1.2),(5,-1.2),GRAY,3),car((-4,0),col=BLUE),car((3.3,0),col=GRAY),rect((-1.7,-2.2),3, .55,GOLD,.16),rect((2,-2.2),4.1,.55,BLUE,.16),txt('Trong lúc trễ',(-1.7,-3),42,GOLD,width=4),txt('Phanh tới 0',(2.3,-3),42,BLUE,width=4),arr((-3,1.4),(.0,1.4),GOLD),arr((.2,1.4),(4.2,1.4),BLUE));return g

def occlusion_scene(n):
 g=road();g.add(car((-3.9,0),col=BLUE),rect((1.2,2.1),2.8,1.35,GRAY,.17),txt('Xe đỗ',(1.2,2.1),39,GRAY,width=2.5))
 poly=m.Polygon(p((-.1,.45)),p((6,3.3)),p((6,-1.3)),stroke_color=GOLD,fill_color=GOLD,fill_opacity=.12,stroke_width=3);g.add(poly,ln((2.7,-1.4),(2.7,1.4),RED,4),txt('Vùng chưa quan sát',(3.8,-2.7),45,GOLD,width=6),arr((-2.6,-2.1),(2.6,-2.1),BLUE),eq(r'D_{\rm visible}',(-.1,-3),52,BLUE,width=6));return g

class Figure(m.Scene):
 def __init__(self,row):super().__init__();self.row=row
 def construct(self):
  r=self.row;n=r['n'];k=r['fig'];g=m.VGroup()
  if r['formula']:self.add(eq(r['formula'],(0,3.35),56,width=13.1))
  if k=='timeline' or k=='break':g=timeline_scene(n)
  elif k in ['intersection','reservation','footprint','priority','go_wait','deadlock','multiagent','mixed_traffic']:g=intersection_scene(k,n)
  elif k in ['slots','occupancy']:g=slots(n)
  elif k in ['ped_scene','ped_static','yield','hri','intent','noncooperative']:g=pedestrian_scene(k,n)
  elif k in ['relative','cpa','ttc','horizon','distance_ttc']:g=relative_scene(k,n)
  elif k in ['braking','stop_distance','delay_compare','quiz_stop','answer_stop']:g=stopping_scene(k,n)
  elif k=='occlusion':g=occlusion_scene(n)
  elif k in ['spacetime','st','path_time','continuous','aliasing']:
   if k=='aliasing':
    ts=np.linspace(0,1,80);g,xy=axes([([(t,-1+2*t)for t in ts],BLUE),([(t,1-2*t)for t in ts],GOLD)],(0,1),(-1.3,1.3),(r't\ (\mathrm s)',r'x\ (\mathrm m)'))
    a,b=xy(.4,-1.3),xy(.6,1.3);g.add(rect(((a[0]+b[0])/2,(a[1]+b[1])/2),b[0]-a[0],b[1]-a[1],RED,.12),txt('Tiếp xúc giữa hai mẫu',(0,-3.25),46,RED,width=12))
   else:
    ts=np.linspace(0,8,100);s1=lambda t:min(20,4*t);s2=lambda t:0 if t<2 else min(20,4*(t-2))
    g,xy=axes([([(t,s1(t))for t in ts],BLUE),([(t,s2(t))for t in ts],GOLD)],(0,8),(0,22))
    a,b=xy(2.2,9),xy(4.0,14);g.add(rect(((a[0]+b[0])/2,(a[1]+b[1])/2),b[0]-a[0],b[1]-a[1],RED,.13),txt('Vùng bị chiếm',(3,2.2),44,RED,width=4.7),txt('Hai lịch trên cùng tuyến',(0,-3.25),44,BLUE,width=12))
  elif k in ['cv','prediction','turn_prediction','multimodal','uncertainty']:
   g=road();g.add(car((-4,0),col=BLUE))
   for j,x in enumerate([-2,0,2,4]):g.add(car((x,.1*j),col=GRAY,scale=.58),eq(str(j+1)+r'\ \mathrm s',(x,-1.7),37,GRAY,width=2))
   if k=='multimodal' or k=='turn_prediction':
    for sign,col in [(1,GOLD),(-1,RED)]:g.add(path([(-3,0),(-1,0),(1,sign*1.1),(3,sign*2.4)],col,5))
   elif k=='uncertainty':
    for j,x in enumerate([-2,0,2,4]):g.add(circ((x,.1*j),.25+.18*j,GOLD,.04))
   g.add(txt('Lịch sử',(-4,2.6),46,BLUE,width=4),txt('Tương lai dự báo',(2,2.6),46,GOLD,width=7))
  elif k in ['latency','freshness']:
   g=m.VGroup(ln((-5,0),(5,0),GRAY,3),dot((-4,0),BLUE,.17),dot((3,0),RED,.17),eq(r't_{\rm stamp}',(-4,-.8),48,BLUE,width=3.7),eq(r't_{\rm now}',(3,-.8),48,RED,width=3),arr((-3.5,.7),(2.5,.7),GOLD),txt('Tuổi dữ liệu',(0,1.7),50,GOLD),car((-4,-2.3),col=BLUE,scale=.8),car((3,-2.3),col=GRAY,scale=.8));
  elif k=='actors' or k=='state':
   g=road();g.add(car((-3.5,0),col=BLUE),car((3.2,0),math.pi,GOLD),person((0,2.3),RED,1.2),txt('Xe ego',(-3.5,-2.5),45,BLUE,width=3.7),txt('Xe khác',(3.2,-2.5),45,GOLD,width=3.7),arr((-3.5,1.5),(-1,1.5),BLUE))
  elif k=='layers':
   for j,(col,label)in enumerate([(GRAY,'Bản đồ tĩnh'),(BLUE,'Theo dõi tác nhân'),(GOLD,'Vùng dự báo')]):
    y=1.8-j*1.8;g.add(rect((-2.5,y),5.3,1.2,col,.07),txt(label,(-2.5,y),42,col,width=5),car((2.2,y),col=col,scale=.65),arr((.4,y),(1.1,y),col,3))
  elif k=='central':
   g.add(rect((0,1.6),4.3,1.2,BLUE),txt('Điều phối',(0,1.6),45,BLUE,width=4))
   for x,col in [(-4,BLUE),(0,GOLD),(4,RED)]:g.add(car((x,-1.6),col=col,scale=.8),arr((x,-.7),(0,.9),col,4))
   g.add(txt('Thông tin chung và quyết định cục bộ',(0,-3),44,GRAY,width=12))
  elif k=='cbs':
   for a,label,col in [((0,1.7),'Xung đột A/B',RED),((-3.5,-1.3),'Ràng buộc A',BLUE),((3.5,-1.3),'Ràng buộc B',GOLD)]:g.add(rect(a,4.1,1.25,col),txt(label,a,43,col,width=3.8))
   g.add(arr((-.7,1),(-3.1,-.55),BLUE),arr((.7,1),(3.1,-.55),GOLD),txt('Tìm lại đường thỏa ràng buộc',(0,-3),45,GRAY,width=12))
  elif k=='mapf_conflict':
   for y in [1.5,-1.4]:
    for x in [-4,0,4]:g.add(circ((x,y),.32,GRAY),ln((x+.4,y),(min(4,x+3.6),y),GRAY,3)if x<4 else dot((x,y),GRAY,.03))
   g.add(arr((-3.5,1.5),(-.5,1.5),BLUE),arr((3.5,1.5),(.5,1.5),GOLD),arr((-3.5,-1.1),(3.5,-1.1),BLUE),arr((3.5,-1.7),(-3.5,-1.7),GOLD),txt('Trùng đỉnh',(0,2.8),45,RED),txt('Đổi chỗ dọc cạnh',(0,-2.9),45,RED))
  elif k in ['vo','orca']:
   g.add(ln((-5,-2),(5,-2),GRAY,3),ln((-5,-2),(-5,2),GRAY,3),m.Polygon(p((-3,-1.5)),p((4,2)),p((4,-1.4)),stroke_color=RED,fill_color=RED,fill_opacity=.12),arr((-3,-1.5),(2,1.0),RED),arr((-3,-1.5),(.5,-1.7),BLUE),eq(r'v_x',(5,-2.8),47,GRAY,width=2),eq(r'v_y',(-5,2.6),47,GRAY,width=2),txt('Vùng vận tốc gây xung đột',(1,3),43,RED,width=10))
   if k=='orca':g.add(ln((0,-2),(1.5,1.9),BLUE,5),txt('Điều kiện tương hỗ',(0,-3.5),43,BLUE,width=9))
  elif k=='fairness':
   for j,w in enumerate([7,2,3,8]):y=1.7-j*1.2;g.add(rect((-5+w/2,y),w,.65,BLUE if j%2==0 else GOLD,.18),txt('A'if j%2==0 else'B',(-5.8,y),42,width=1),eq(str(w)+r'\ \mathrm s',(4.1,y),40,GRAY,width=2))
   g.add(txt('Đọc cả mức chờ lớn nhất',(0,-3.4),45,RED,width=11))
  elif k=='hysteresis':
   xx=np.linspace(0,8,150);g,xy=axes([([(t,.5+.14*math.sin(5*t))for t in xx],GRAY)],(0,8),(0,1),(r't\ (\mathrm s)',r'\text{tín hiệu}'))
   for v,col in [(.4,GOLD),(.6,BLUE)]:g.add(ln(xy(0,v),xy(8,v),col,4))
   g.add(txt('Hai ngưỡng để tránh đổi ý sát biên',(0,-3.3),43,BLUE,width=12))
  elif k=='cyclist':
   g=road();g.add(car((-3.6,0),col=BLUE),circ((2,-.3),.4,GOLD,0),circ((3.5,-.3),.4,GOLD,0),ln((2,-.3),(2.65,.45),GOLD,4),ln((2.65,.45),(3.5,-.3),GOLD,4),ln((2,-.3),(3.5,-.3),GOLD,4),person((2.7,.9),GOLD,.8),arr((-3.5,2.5),(3.6,2.5),BLUE),txt('Giữ khoảng và dự báo hành vi',(0,-2.8),45,BLUE,width=12))
  elif k=='evidence':
   for x,label,col in [(-3.6,'Sự kiện thật',BLUE),(3.6,'Phát lại mô phỏng',GOLD)]:g.add(rect((x,.5),5.3,2.4,col),txt(label,(x,.9),45,col,width=5),txt('Có can thiệp'if x<0 else'Giả định của mô hình',(x,-.1),39,col,width=5))
   g.add(arr((-.8,.5),(.8,.5),GRAY),txt('Giữ hai loại bằng chứng riêng',(0,-2.5),47,RED,width=12))
  elif k in ['results_intersection','sensitivity']:
   if k=='results_intersection':
    curves=[]
    for j,col in [(0,BLUE),(1,GOLD)]:run=DATA['intersection'][1];curves.append(([(f['t'],f['A']['x'] if j==0 else f['B']['y'])for f in run['frames']],col))
    g,xy=axes(curves,(0,12.2),(-18,28),(r't\ (\mathrm s)',r'x_A\ (\mathrm m)'));g.add(txt('Vị trí A (xanh) và B (vàng) theo tuyến',(0,-3.3),43,BLUE,width=12))
   else:
    taus=np.linspace(0,1.2,100);g,xy=axes([([(t,8*t+64/6)for t in taus],BLUE)],(0,1.2),(9,22),(r'\tau_d\ (\mathrm s)',r'd_{\rm stop}\ (\mathrm m)'));g.add(txt('Giữ vận tốc và độ lớn giảm tốc',(0,-3.3),43,GOLD,width=12))
  elif k=='test_matrix':
   for j,label in enumerate(['Trễ','Tốc độ','Tầm nhìn']):
    for i,lev in enumerate(['Thấp','Giữa','Cao']):g.add(rect((-2.5+i*2.6,1.5-j*1.4),2.3,1.1,BLUE if (i+j)%2==0 else GOLD),txt(lev,(-2.5+i*2.6,1.5-j*1.4),39,width=2))
    g.add(txt(label,(-5.4,1.5-j*1.4),42,GRAY,width=2.2))
   g.add(txt('Kịch bản gốc + thay đổi có chủ đích',(0,-3.4),44,BLUE,width=12))
  elif k=='metrics':
   for x,lab,value,col in [(-4.6,'Tiếp xúc','Có / không',RED),(0,'Hoàn thành','Thời gian',BLUE),(4.6,'Độ êm','Mô hình gia tốc',GOLD)]:g.add(rect((x,.3),4,2.6,col),txt(lab,(x,1),44,col,width=3.7),txt(value,(x,-.3),39,col,width=3.7))
   g.add(txt('Không gộp các đơn vị khi chưa định nghĩa',(0,-2.4),43,GRAY,width=13))
  else:
   labels={'pipeline':['Quan sát','Dự đoán','Phối hợp','Kiểm lại'],'objectives':['Thời gian','Xung đột','Kiểm thử'],'quiz_before':['Lịch','Ưu tiên','Kiểm khoảng'],'replan':['Cập nhật','Lập lại','Kiểm','Áp dụng'],'acceptance':['Hình học','Chuyển động','Hoàn thành'],'margins':['Biên vị trí','Đệm giờ','Phép kiểm'],'feedback':['Quan sát mới','Sai khác','Tính lại'],'edge_cases':['Mất dấu','Đổi hướng','Trễ hạn'],'workshop':['Mô hình','Phép thử','Bằng chứng'],'workshop_answer':['Khoảng nhìn','Khoảng dừng','Kiểm lại'],'quiz_claims':['Giả định','Kết luận','Phản ví dụ'],'quiz_answer':['Thời gian','Mô hình','Giới hạn'],'ros':['Theo dõi','Dự báo','Planner','Kiểm lệnh'],'summary':['Giao lộ','Người đi bộ','Vùng khuất'],'homework':['Cấu hình','Dữ liệu','Giải thích'],'resources':['Teaching','Mã và dữ liệu','Nguồn gốc'],'next':['Quyết định','Mục tiêu','Kế hoạch']}
   if k not in labels:raise ValueError((n,k))
   g=flow(labels[k],k in ['replan','feedback','summary'])
   if k in ['quiz_before','workshop','quiz_claims','quiz_answer','homework']:g.add(eq(r'\mathcal B_A(t)\cap\mathcal B_B(t)=\varnothing',(0,-2.3),61,GOLD,width=11))
  if g.width>13 or g.height>5.4:g.scale(min(13/g.width,5.4/g.height))
  g.move_to([0,-.5 if r['formula']else 0,0]);self.add(g)

def export():
 selected={int(x)for x in sys.argv[1:]};manifest=[]
 skip={'cover','table','carla_video','waymo_video','shot_safe','shot_late','shot_occlusion','intersection_recording','occlusion_recording'}
 for row in PLAN:
  if row['fig']in skip or(selected and row['n']not in selected):continue
  sc=Figure(row);sc.construct();group=m.VGroup(*sc.mobjects);group.scale(min(1,13.4/group.width,7.45/group.height)).move_to([0,0,0]);frames=[]
  def capture(frame):
   if not frames:frames.append(Image.frombytes('RGBA',(3200,1800),frame.pixels()))
  sc.construct=lambda:sc.wait(1/30);sc.render(frames=capture)
  im=frames[0];bb=im.getchannel('A').getbbox();assert bb
  x0,y0,x1,y1=bb;im=im.crop((max(0,x0-45),max(0,y0-45),min(3200,x1+45),min(1800,y1+45)));bg=Image.new('RGB',im.size,'white');bg.paste(im,mask=im.getchannel('A'));bg.thumbnail((2600,1900),Image.Resampling.LANCZOS);name=f'slide-{row["n"]:02}.png';bg.save(O/name,optimize=True)
  embed=bg.copy();embed.thumbnail((1700,1300),Image.Resampling.LANCZOS);embed.quantize(colors=224,method=Image.Quantize.MEDIANCUT).save(O/('embed-'+name),optimize=True)
  manifest.append(dict(n=row['n'],file='embed-'+name,w=embed.width,h=embed.height,engine='ManimGX 0.1.1',inkBounds=bb));print(row['n'],row['fig'],embed.size,flush=True)
 if selected and(O/'manifest.json').exists():manifest=sorted([d for d in json.loads((O/'manifest.json').read_text())if d['n']not in selected]+manifest,key=lambda d:d['n'])
 (O/'manifest.json').write_text(json.dumps(manifest,indent=2))
if __name__=='__main__':export()
