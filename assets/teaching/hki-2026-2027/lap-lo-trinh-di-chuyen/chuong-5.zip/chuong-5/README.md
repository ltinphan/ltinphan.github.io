# Chương 5: Lập lộ trình trong môi trường phức tạp

Mở `demo.html` bằng trình duyệt. Không cần kết nối xe, cài ROS hay tải thư viện từ mạng. Các số của phần tương tác được tính ngay trong trình duyệt.

## Ba phần thực hành

1. Giao lộ: so cùng đi với đặt chỗ. Gốc có biên 0,3 m, đệm 0,5 s, hai xe 4,4 × 1,8 m, tuyến vuông góc. B chờ 2,2 s nếu A trước. Hai xe từ đứng yên tăng tốc 2 m/s² tới 4 m/s. Mốc đích là đi qua vạch, chưa thiết kế phanh cuối tuyến.
2. Người đi bộ: xe ở −18 m, 8 m/s; người ở (0,−3) m, đi thẳng đều 1,5 m/s, hình vuông cạnh 0,6 m. So giữ vận tốc và nhường với trễ 0,2 / 0,8 s. Chế độ nhường phanh đều 3 m/s² tới khi dừng, chờ theo dự báo có biên 0,5 m và đệm 0,4 s rồi tăng tốc lại 2 m/s². Dữ liệu người được biết ở t=0; trễ là thời gian tới khi bắt đầu phanh, chưa mô phỏng cảm biến trễ.
3. Vùng khuất: khoảng nhìn từ mép trước 8 m, giữ lại 2 m, trễ 0,6 s, phanh 3 m/s². Cận vận tốc 4,464183905 m/s cho quãng dừng 6 m. Cận được chọn trước khi tới trạng thái lộ vùng, chưa phải lệnh giảm tức thì từ 8 m/s. Chưa có người ẩn được mô phỏng.

## Kiểm chứng và tái lập

`data/reference-results.json` và CSV lưu các lần chạy gốc và biến thể. Trong demo, nút Lưu JSON giữ cả cấu hình, kết quả kiểm và trạng thái; nút Lưu CSV giữ trạng thái theo thời gian. Thời điểm hoạt hình được làm tròn về mốc 0,05 s để hiển thị, còn bộ kiểm tiếp xúc dùng nghiệm biên trên từng đoạn gia tốc không đổi. Tiếp xúc cũng tính là va chạm. Khoảng hở lấy mẫu 1 ms được báo riêng, không phải cực tiểu liên tục đã chứng nhận.

Mã lõi ở `src/engine.mjs`. Có Node.js thì chạy lại kiểm số từ thư mục gói:

```
mkdir -p build
cp src/engine.mjs src/verify-engine.mjs build/
node build/verify-engine.mjs
```

Mã kiểm dùng một triển khai tích phân độc lập theo từng cấu hình và bước 0,1 ms để đối chiếu 36 trường hợp người đi bộ; thêm 12 trường hợp vùng khuất và 8 trường hợp đặt chỗ. Phản ví dụ lấy hai đầu bỏ sót khoảng tiếp xúc [0,4;0,6] s cũng được kiểm.

## Video và hình

`videos/` chứa ba video ghép từ chuỗi ảnh chụp trực tiếp khung canvas của demo theo từng mốc thời gian. Thời gian phát có thể khác thời gian mô hình; dấu giờ mô hình nằm trong hình. Video CARLA và Waymo ở nguồn chính thức trên Teaching, không sao chép vào gói. `figures/` là ảnh chụp thực của các cấu hình trong bài. Nguồn ManimGX của hình mới ở `src/figures.py`; chạy phần dựng hình cần ManimGX 0.1.1, NumPy, Pillow và các thư viện được ManimGX yêu cầu. Bài giảng và ghi chú giảng viên không nằm trong gói sinh viên.

## Phạm vi

Mô phỏng giáo dục hai chiều, tuyến thẳng, hình chữ nhật song song trục và gia tốc hằng theo đoạn. Chưa có giới hạn jerk, lốp, độ dốc hoặc cơ cấu chấp hành. Chưa là một planner giao thông hoàn chỉnh, triển khai ROS 2, kiểm chứng CARLA hay phép thử xe thật. Không dùng các cấu hình này để điều khiển phương tiện.
